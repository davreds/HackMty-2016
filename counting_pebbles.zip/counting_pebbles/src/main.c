#include <pebble.h>

//Display variables
static Window *s_main_window;
static TextLayer *s_mainCounter_layer;
static TextLayer *s_secondCounter_layer;
static TextLayer *s_thirdCounter_layer;
static TextLayer *s_time_layer;
static GFont s_time_font;
static GFont s_counter1_font;
static GFont s_counter2_font;
static BitmapLayer *s_background_layer;
static GBitmap *s_background_bitmap;

//Program variables
int i_mainCounter = 0;
int i_secondCounter = 0;
int i_thirdCounter = 0;

//Method to transform integers to strings
    //Credits to user: FlashBIOS; retrieved from https://forums.getpebble.com/discussion/comment/29591
static char *itoa(int num){
  
  char *buff = malloc(20*sizeof(char));
  int i = 0, temp_num = num, length = 0;
    char *string = buff;
    if(num >= 0) {
        // count how many characters in the number
        while(temp_num) {
            temp_num /= 10;
            length++;
        }
        // assign the number to the buffer starting at the end of the
        // number and going to the begining since we are doing the
        // integer to character conversion on the last number in the
        // sequence
        for(i = 0; i < length; i++) {
            buff[(length-1)-i] = '0' + (num % 10);
            num /= 10;
        }
        buff[i] = '\0'; // can't forget the null byte to properly end our string
    } else
        return "Unsupported Number";
    return string;
}

static void update_time() {
  time_t temp = time(NULL);
  struct tm *tick_time = localtime(&temp);

  static char s_buffer[8];
  strftime(s_buffer, sizeof(s_buffer), clock_is_24h_style() ?
                                          "%H:%M" : "%I:%M", tick_time);
  
  text_layer_set_text(s_time_layer, s_buffer);
}

static void select_click_handler(ClickRecognizerRef recognizer, void *context) {
  if(i_mainCounter < 99){
    i_mainCounter++;
    //s_num = itoa(i_mainCounter);
    text_layer_set_text(s_mainCounter_layer, itoa(i_mainCounter));
    //free(s_num);
  } else{
    i_thirdCounter = i_secondCounter;
    //s_num = itoa(i_thirdCounter);
    text_layer_set_text(s_thirdCounter_layer, itoa(i_thirdCounter));
    //free(s_num);
    i_secondCounter = 99;
    text_layer_set_text(s_secondCounter_layer, "99");
    i_mainCounter = 1;
    text_layer_set_text(s_mainCounter_layer, "1");
  }
}

static void up_click_handler(ClickRecognizerRef recognizer, void *context) {
  //char *s_num;
  i_thirdCounter = i_secondCounter;
  i_secondCounter = i_mainCounter;
  i_mainCounter = 0;
  //s_num = itoa(i_mainCounter);
  text_layer_set_text(s_mainCounter_layer,itoa(i_mainCounter));
  //free(s_num);
  //s_num = itoa(i_secondCounter);
  text_layer_set_text(s_secondCounter_layer, itoa(i_secondCounter));
  //free(s_num);
  //s_num = itoa(i_thirdCounter);
  text_layer_set_text(s_thirdCounter_layer, itoa(i_thirdCounter));
  //free(s_num);
}

static void down_click_handler(ClickRecognizerRef recognizer, void *context) {
  i_mainCounter = 0;
  i_secondCounter = 0;
  i_thirdCounter = 0;
  text_layer_set_text(s_mainCounter_layer, "0");
  text_layer_set_text(s_secondCounter_layer, "0");
  text_layer_set_text(s_thirdCounter_layer, "0");
}

static void click_config_provider(void *context) {
  window_single_click_subscribe(BUTTON_ID_SELECT, select_click_handler);
  window_single_click_subscribe(BUTTON_ID_UP, up_click_handler);
  window_single_click_subscribe(BUTTON_ID_DOWN, down_click_handler);
}

static void window_load(Window *window) {
  // Get information about the Window
  Layer *window_layer = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(window_layer);
  
  // Create GBitmap
  s_background_bitmap = gbitmap_create_with_resource(RESOURCE_ID_IMAGE_BACKGROUND);

  // Create BitmapLayer to display the GBitmap
  s_background_layer = bitmap_layer_create(bounds);

  // Set the bitmap onto the layer and add to the window
  bitmap_layer_set_bitmap(s_background_layer, s_background_bitmap);
  layer_add_child(window_layer, bitmap_layer_get_layer(s_background_layer));
  
  // Create the Time Layer with specific bounds
  s_time_layer = text_layer_create(
      GRect(0, 0, bounds.size.w, 11));
  text_layer_set_background_color(s_time_layer, GColorClear);
  text_layer_set_text_color(s_time_layer, GColorWhite);
  text_layer_set_text(s_time_layer, "00:00");
  text_layer_set_text_alignment(s_time_layer, GTextAlignmentCenter);
  layer_add_child(window_layer, text_layer_get_layer(s_time_layer));
  
  // Create the Counter Layers with specific bounds
  s_mainCounter_layer = text_layer_create(
      GRect(23, 35, 80, 64));
  text_layer_set_background_color(s_mainCounter_layer, GColorClear);
  text_layer_set_text_color(s_mainCounter_layer, GColorBlack);
  text_layer_set_text(s_mainCounter_layer, "0");
  text_layer_set_text_alignment(s_mainCounter_layer, GTextAlignmentCenter);
  layer_add_child(window_layer, text_layer_get_layer(s_mainCounter_layer));
  
  s_secondCounter_layer = text_layer_create(
      GRect(61, 108, 48, 18));
  text_layer_set_background_color(s_secondCounter_layer, GColorClear);
  text_layer_set_text_color(s_secondCounter_layer, GColorBlack);
  text_layer_set_text(s_secondCounter_layer, "0");
  text_layer_set_text_alignment(s_secondCounter_layer, GTextAlignmentCenter);
  layer_add_child(window_layer, text_layer_get_layer(s_secondCounter_layer));
  
  s_thirdCounter_layer = text_layer_create(
      GRect(61, 138, 48, 18));
  text_layer_set_background_color(s_thirdCounter_layer, GColorClear);
  text_layer_set_text_color(s_thirdCounter_layer, GColorBlack);
  text_layer_set_text(s_thirdCounter_layer, "0");
  text_layer_set_text_alignment(s_thirdCounter_layer, GTextAlignmentCenter);
  layer_add_child(window_layer, text_layer_get_layer(s_thirdCounter_layer));
  
  //Create GFonts
      //Credits to webpagepublicity.com; retrieved from http://www.webpagepublicity.com/free-fonts-x.html
  s_time_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_XEROX_SANS_9));
  text_layer_set_font(s_time_layer, s_time_font);
  s_counter1_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_XENOTRON_40));
  text_layer_set_font(s_mainCounter_layer, s_counter1_font);
  s_counter2_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_XENOTRON_16));
  text_layer_set_font(s_secondCounter_layer, s_counter2_font);
  text_layer_set_font(s_thirdCounter_layer, s_counter2_font);
}

static void window_unload(Window *window) {
  // Destroy TextLayers
  text_layer_destroy(s_time_layer);
  text_layer_destroy(s_mainCounter_layer);
  text_layer_destroy(s_secondCounter_layer);
  text_layer_destroy(s_thirdCounter_layer);
  
  // Unload GFonts
  //fonts_unload_custom_font(s_time_font);
  fonts_unload_custom_font(s_counter1_font);
  fonts_unload_custom_font(s_counter2_font);
  
  // Destroy GBitmap
  gbitmap_destroy(s_background_bitmap);

  // Destroy BitmapLayer
  bitmap_layer_destroy(s_background_layer);
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  update_time();
}

static void init(void) {
  //Create main window
  s_main_window = window_create();
  window_set_window_handlers(s_main_window, (WindowHandlers) {
    .load = window_load,
    .unload = window_unload,
  });
  window_set_click_config_provider(s_main_window, click_config_provider);
  
  window_stack_push(s_main_window, true);
  
  // Register with TickTimerService
  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
  
  // Make sure the time is displayed from the start
  update_time();
}

static void deinit(void) {
  //Destory main window
  window_destroy(s_main_window);
}

int main(void) {
  init();
  app_event_loop();
  deinit();
}